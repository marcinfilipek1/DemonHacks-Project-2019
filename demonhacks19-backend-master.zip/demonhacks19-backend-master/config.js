module.exports = {
  secret: process.env.SECRET
}