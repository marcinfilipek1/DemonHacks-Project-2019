export class Location {
  lat: number;
  lon: number;
}