import { Location } from '../location'

export class Consumer {
  email: string;
  password: string;
  age: string;
  gender: string;
  location: Location;
}